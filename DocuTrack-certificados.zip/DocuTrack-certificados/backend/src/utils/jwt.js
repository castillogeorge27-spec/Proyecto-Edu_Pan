import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
dotenv.config();

export function signJwt(payload, expiresIn='2h') {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn });
}

export function verifyJwt(token) {
  return jwt.verify(token, process.env.JWT_SECRET);
}
