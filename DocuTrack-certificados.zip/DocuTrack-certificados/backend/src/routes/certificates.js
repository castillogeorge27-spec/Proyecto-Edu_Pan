import { Router } from 'express';
import { query } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { generateCertificatePDF } from '../services/pdf.js';
import fs from 'fs';
import path from 'path';
import { io } from '../index.js';

const router = Router();

// Crear solicitud de certificado
router.post('/', requireAuth, async (req, res) => {
  const { content, requester_name } = req.body;
  const trackingCode = 'TRK-' + Math.random().toString(36).slice(2,8).toUpperCase();
  const { rows } = await query(
    `INSERT INTO certificates (user_id, content, tracking_code, status, requester_name, requester_email)
     VALUES ($1,$2,$3,'pending',$4,(SELECT email FROM users WHERE id=$1)) 
     RETURNING *`,
    [req.user.id, content || '', trackingCode, requester_name || null]
  );
  const cert = rows[0];
  await query(
    'INSERT INTO certificate_events (certificate_id, status, note) VALUES ($1,$2,$3)',
    [cert.id, 'pending', 'Solicitud creada']
  );
  res.status(201).json(cert);
});

// Listar mis certificados
router.get('/', requireAuth, async (req, res) => {
  const { rows } = await query('SELECT * FROM certificates WHERE user_id=$1 ORDER BY created_at DESC', [req.user.id]);
  res.json(rows);
});

// Obtener certificado por id (propietario)
router.get('/:id', requireAuth, async (req, res) => {
  const { rows } = await query('SELECT * FROM certificates WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
  if (rows.length === 0) return res.status(404).json({ error: 'No encontrado' });
  res.json(rows[0]);
});

// Seguimiento: eventos
router.get('/:id/events', requireAuth, async (req, res) => {
  const { rows } = await query(
    'SELECT * FROM certificate_events WHERE certificate_id=$1 ORDER BY created_at ASC', 
    [req.params.id]
  );
  res.json(rows);
});

// Descargar PDF (seguro)
router.get('/:id/download', requireAuth, async (req, res) => {
  const { rows } = await query('SELECT * FROM certificates WHERE id=$1', [req.params.id]);
  const cert = rows[0];
  if (!cert) return res.status(404).json({ error: 'No encontrado' });
  if (req.user.role !== 'admin' && cert.user_id !== req.user.id) {
    return res.status(403).json({ error: 'No autorizado' });
  }
  if (!cert.pdf_path || !fs.existsSync(cert.pdf_path)) {
    return res.status(409).json({ error: 'PDF aún no generado' });
  }
  res.download(path.resolve(cert.pdf_path));
});

export default router;
