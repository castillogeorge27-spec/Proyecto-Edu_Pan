// routes/auth.js
import express from 'express'
import pool from '../db.js'

const router = express.Router()

router.post('/register', async (req, res) => {
  const { email, password, full_name } = req.body
  try {
    const result = await pool.query(
      `INSERT INTO users (email, password, full_name, role)
       VALUES ($1, $2, $3, 'user')
       RETURNING id, email, full_name, role`,
      [email, password, full_name] // 👈 ahora se guarda en texto plano
    )
    res.json(result.rows[0])
  } catch (err) {
    console.error(err)
    res.status(400).json({ error: 'No se pudo registrar el usuario' })
  }
})

export default router

