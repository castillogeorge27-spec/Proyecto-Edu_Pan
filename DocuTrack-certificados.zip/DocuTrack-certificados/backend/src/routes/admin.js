import { Router } from 'express';
import { query } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { generateCertificatePDF } from '../services/pdf.js';
import { io } from '../index.js';

const router = Router();

// Resumen para panel
router.get('/dashboard', requireAuth, requireRole('admin'), async (req, res) => {
  const total = await query('SELECT COUNT(*) FROM certificates');
  const pending = await query("SELECT COUNT(*) FROM certificates WHERE status='pending'");
  const approved = await query("SELECT COUNT(*) FROM certificates WHERE status='approved'");
  const rejected = await query("SELECT COUNT(*) FROM certificates WHERE status='rejected'");
  res.json({
    total: Number(total.rows[0].count),
    pending: Number(pending.rows[0].count),
    approved: Number(approved.rows[0].count),
    rejected: Number(rejected.rows[0].count)
  });
});

// Listar trámites
router.get('/requests', requireAuth, requireRole('admin'), async (req, res) => {
  const { rows } = await query(
    `SELECT c.*, u.email AS user_email
     FROM certificates c JOIN users u ON u.id = c.user_id
     ORDER BY c.created_at DESC`
  );
  res.json(rows);
});

// Validar / cambiar estado
router.patch('/requests/:id/status', requireAuth, requireRole('admin'), async (req, res) => {
  const { status, note } = req.body; // 'approved' | 'rejected' | 'in_progress' | 'ready'
  const { rows } = await query(
    'UPDATE certificates SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
    [status, req.params.id]
  );
  if (rows.length === 0) return res.status(404).json({ error: 'No encontrado' });
  await query(
    'INSERT INTO certificate_events (certificate_id, status, note) VALUES ($1,$2,$3)',
    [req.params.id, status, note || null]
  );
  // Notificar en tiempo real al room del tracking_code e id
  const roomA = rows[0].tracking_code;
  const roomB = String(rows[0].id);
  io.to(roomA).emit('statusUpdated', { id: rows[0].id, status });
  io.to(roomB).emit('statusUpdated', { id: rows[0].id, status });
  res.json(rows[0]);
});

// Generar PDF (normalmente tras aprobar)
router.post('/requests/:id/generate-pdf', requireAuth, requireRole('admin'), async (req, res) => {
  const { rows } = await query('SELECT * FROM certificates WHERE id=$1', [req.params.id]);
  const cert = rows[0];
  if (!cert) return res.status(404).json({ error: 'No encontrado' });
  const result = await generateCertificatePDF(cert);
  const updated = await query('UPDATE certificates SET pdf_path=$1, status=$2 WHERE id=$3 RETURNING *',
    [result.path, 'ready', cert.id]);
  res.json(updated.rows[0]);
});

export default router;
