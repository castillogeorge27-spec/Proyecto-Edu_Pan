import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import dotenv from 'dotenv';
dotenv.config();

export function ensureStorage() {
  const dir = process.env.FILE_STORAGE_DIR || './storage/certificates';
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function generateCertificatePDF(certificate) {
  const dir = ensureStorage();
  const filename = `cert_${certificate.id}.pdf`;
  const fullPath = path.join(dir, filename);

  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  const stream = fs.createWriteStream(fullPath);
  doc.pipe(stream);

  doc.fontSize(20).text('CERTIFICADO', { align: 'center' });
  doc.moveDown();
  doc.fontSize(12).text(`Certificado ID: ${certificate.id}`);
  doc.text(`Código de seguimiento: ${certificate.tracking_code}`);
  doc.text(`Solicitante: ${certificate.requester_name || 'N/A'}`);
  doc.text(`Email: ${certificate.requester_email || 'N/A'}`);
  doc.text(`Estado: ${certificate.status}`);
  doc.moveDown();
  doc.text('Contenido:', { underline: true });
  doc.text(certificate.content || '—');

  doc.moveDown();
  doc.fontSize(10).text(`Emitido: ${new Date().toLocaleString()}`);
  doc.end();

  return new Promise((resolve, reject) => {
    stream.on('finish', () => resolve({ path: fullPath, filename }));
    stream.on('error', reject);
  });
}
