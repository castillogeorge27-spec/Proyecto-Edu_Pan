import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { Server } from 'socket.io';

import authRoutes from './routes/auth.js';
import certRoutes from './routes/certificates.js';
import adminRoutes from './routes/admin.js';

dotenv.config();

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/certificates', certRoutes);
app.use('/api/admin', adminRoutes);

// Salud
app.get('/api/health', (req, res) => res.json({ ok: true }));

const httpServer = createServer(app);
export const io = new Server(httpServer, {
  cors: { origin: process.env.CLIENT_ORIGIN }
});
io.on('connection', (socket) => {
  // El cliente debe unirse a una sala por tracking_code o id
  socket.on('joinCertRoom', (room) => socket.join(room));
});

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => console.log(`API escuchando en http://localhost:${PORT}`));
