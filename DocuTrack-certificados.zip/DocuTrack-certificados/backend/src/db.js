// db.js
import pkg from 'pg';
const { Pool } = pkg;

export const pool = new Pool({
  user: 'postgres',     // tu usuario
  password: 'gc13',     // tu contraseña de pgAdmin
  host: 'localhost',
  port: 5432,
  database: 'certificadosdb', // tu base de datos
  ssl: false
});

export default pool;
