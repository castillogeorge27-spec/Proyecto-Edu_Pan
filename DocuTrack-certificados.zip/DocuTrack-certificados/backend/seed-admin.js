import db from "./src/db.js";

async function seedAdmin() {
  try {
    const name = "Administrador";
    const email = "admin@demo.com";
    const password = "admin123"; // texto plano
    const role = "ADMIN";

    await db.query(
      `INSERT INTO users (name, email, password, role)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (email) DO NOTHING`,
      [name, email, password, role]
    );

    console.log("✅ Usuario administrador creado con éxito");
    process.exit(0);
  } catch (err) {
    console.error("❌ Error creando admin:", err.message);
    process.exit(1);
  }
}

seedAdmin();
