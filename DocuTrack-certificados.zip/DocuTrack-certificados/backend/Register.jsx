await api.post('/auth/register', { email, password, full_name })
