import fs from 'fs';
import { pool } from '../src/db.js';

const file = process.argv[2];
if (!file) {
  console.error('Uso: node scripts/migrate.js <ruta_sql>');
  process.exit(1);
}
const sql = fs.readFileSync(file, 'utf8');
(async () => {
  try {
    await pool.query(sql);
    console.log('Migración aplicada.');
  } catch (e) {
    console.error('Error en migración:', e);
    process.exit(1);
  } finally {
    await pool.end();
  }
})();
