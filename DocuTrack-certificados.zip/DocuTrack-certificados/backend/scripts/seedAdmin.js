import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { pool } from '../src/db.js';
dotenv.config();

const email = process.env.ADMIN_EMAIL || 'admin@demo.com';
const password = process.env.ADMIN_PASSWORD || 'admin123';

(async () => {
  try {
    const hash = await bcrypt.hash(password, 10);
    const res = await pool.query(
      `INSERT INTO users (email, password_hash, full_name, role)
       VALUES ($1,$2,'Administrador','admin')
       ON CONFLICT (email) DO UPDATE SET role='admin'
       RETURNING id, email, role`,
      [email.toLowerCase(), hash]
    );
    console.log('Admin listo:', res.rows[0]);
  } catch (e) {
    console.error('Error seeding admin:', e);
    process.exit(1);
  } finally {
    await pool.end();
  }
})();
