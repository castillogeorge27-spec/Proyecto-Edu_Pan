-- Usuarios con roles (user/admin)
CREATE TABLE IF NOT EXISTS users (
  id           SERIAL PRIMARY KEY,
  email        TEXT UNIQUE NOT NULL,
  password     TEXT NOT NULL, -- 'password',
  full_name    TEXT,
  role         TEXT NOT NULL CHECK (role IN ('user','admin')) DEFAULT 'user',
  created_at   TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Certificados/Trámites
CREATE TABLE IF NOT EXISTS certificates (
  id              SERIAL PRIMARY KEY,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content         TEXT,
  requester_name  TEXT,
  requester_email TEXT,
  tracking_code   TEXT UNIQUE NOT NULL,
  status          TEXT NOT NULL CHECK (status IN ('pending','in_progress','approved','rejected','ready')) DEFAULT 'pending',
  pdf_path        TEXT,
  created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cert_user ON certificates(user_id);
CREATE INDEX IF NOT EXISTS idx_cert_tracking ON certificates(tracking_code);

-- Historial de eventos para seguimiento
CREATE TABLE IF NOT EXISTS certificate_events (
  id             SERIAL PRIMARY KEY,
  certificate_id INTEGER NOT NULL REFERENCES certificates(id) ON DELETE CASCADE,
  status         TEXT NOT NULL,
  note           TEXT,
  created_at     TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE EXTENSION IF NOT EXISTS pgcrypto;
SELECT * FROM users;
