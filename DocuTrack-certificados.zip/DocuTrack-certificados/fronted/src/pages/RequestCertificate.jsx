import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../utils/api.js'
import './requestCertificate.css'

export default function RequestCertificate() {
  const [requester_name, setName] = useState('')
  const [content, setContent] = useState('')
  const [error, setError] = useState(null)
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError(null)
    try {
      const { data } = await api.post('/certificates', { requester_name, content })
      nav('/dashboard')
    } catch (e) {
      setError(e.response?.data?.error || 'Error')
    }
  }

  return (
    <div className="request-container">
      <div className="request-box">
        <h2>Solicitud de Certificado</h2>
        <form onSubmit={submit}>
          <input
            type="text"
            placeholder="Tu nombre"
            value={requester_name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <textarea
            placeholder="Contenido del certificado"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
          />
          {error && <div style={{ color: 'red', marginTop: '0.5rem' }}>{error}</div>}
          <button type="submit">Enviar</button>
        </form>
      </div>
    </div>
  )
}

