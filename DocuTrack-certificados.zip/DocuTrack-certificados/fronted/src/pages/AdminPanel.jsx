import { useEffect, useState } from 'react'
import api from '../utils/api.js'
import './adminPanel.css'

export default function AdminPanel() {
  const [dash, setDash] = useState(null)
  const [items, setItems] = useState([])

  const load = async () => {
    const d = await api.get('/admin/dashboard')
    setDash(d.data)
    const reqs = await api.get('/admin/requests')
    setItems(reqs.data)
  }

  useEffect(() => { load() }, [])

  const change = async (id, status) => {
    await api.patch(`/admin/requests/${id}/status`, { status, note: 'Actualizado desde panel' })
    await load()
  }

  const genPdf = async (id) => {
    await api.post(`/admin/requests/${id}/generate-pdf`)
    await load()
  }

  return (
    <div className="admin-container">
      <h2>Panel de Administración</h2>

      {dash && (
        <div className="admin-stats">
          <div>Total: {dash.total}</div>
          <div>Pendientes: {dash.pending}</div>
          <div>Aprobados: {dash.approved}</div>
          <div>Rechazados: {dash.rejected}</div>
        </div>
      )}

      <h3>Trámites</h3>
      <div className="table-wrapper">
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th><th>Usuario</th><th>Estado</th><th>Tracking</th><th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {items.map(x => (
              <tr key={x.id}>
                <td>{x.id}</td>
                <td>{x.user_email}</td>
                <td>{x.status}</td>
                <td>{x.tracking_code}</td>
                <td className="actions">
                  <button onClick={()=>change(x.id,'in_progress')}>En proceso</button>
                  <button onClick={()=>change(x.id,'approved')}>Aprobar</button>
                  <button onClick={()=>change(x.id,'rejected')}>Rechazar</button>
                  <button onClick={()=>genPdf(x.id)}>Generar PDF</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

