import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../state/AuthContext.jsx'
import api from '../utils/api.js'
import './register.css'

export default function Register() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [full_name, setFullName] = useState('')
  const [error, setError] = useState(null)
  const nav = useNavigate()
  const { login } = useAuth()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    try {
      const { data } = await api.post('/auth/register', { email, password, full_name })
      login(data)
      nav('/dashboard')
    } catch (e) {
      setError(e.response?.data?.error || 'Error')
    }
  }

  return (
    <div className="register-container">
      <div className="register-box">
        <h2>Crear cuenta</h2>
        <form onSubmit={onSubmit}>
          <input
            type="text"
            placeholder="Nombre completo"
            value={full_name}
            onChange={(e) => setFullName(e.target.value)}
            required
          />
          <input
            type="email"
            placeholder="Correo electrónico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {error && <div style={{ color: 'red', marginTop: '0.5rem' }}>{error}</div>}
          <button type="submit">Registrarse</button>
        </form>
        <a href="/login">¿Ya tienes cuenta? Inicia sesión</a>
      </div>
    </div>
  )
}

