import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../state/AuthContext.jsx'
import api from '../utils/api.js'
import './login.css'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const nav = useNavigate()
  const { login } = useAuth()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    try {
      const { data } = await api.post('/auth/login', { email, password })
      login(data)
      nav('/dashboard')
    } catch (e) {
      setError(e.response?.data?.error || 'Error')
    }
  }

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Acceder</h2>
        <form onSubmit={onSubmit}>
          <input
            type="email"
            placeholder="Correo electrónico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {error && <div style={{ color: 'red', marginTop: '0.5rem' }}>{error}</div>}
          <button type="submit">Ingresar</button>
        </form>
        <a href="#">¿Olvidaste tu contraseña?</a>
      </div>
    </div>
  )
}
