import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../utils/api.js'

export default function Dashboard() {
  const [items, setItems] = useState([])
  useEffect(() => {
    (async () => {
      const { data } = await api.get('/certificates')
      setItems(data)
    })()
  }, [])
  return (
    <div>
      <h2>Mis certificados</h2>
      <Link to="/request">+ Solicitar certificado</Link>
      <ul>
        {items.map(c => (
          <li key={c.id}>
            #{c.id} - {c.status} - <Link to={`/track/${c.id}`}>Seguimiento</Link>
            {c.status === 'ready' && <a href={`${import.meta.env.VITE_API_URL}/certificates/${c.id}/download`} style={{marginLeft:8}}>Descargar</a>}
          </li>
        ))}
      </ul>
    </div>
  )
}
