import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { io } from 'socket.io-client'
import api from '../utils/api.js'

const socket = io(import.meta.env.VITE_API_URL.replace('/api','').replace(/\/$/, ''))

export default function Track() {
  const { id } = useParams()
  const [events, setEvents] = useState([])
  const [status, setStatus] = useState('')

  useEffect(() => {
    (async () => {
      const { data } = await api.get(`/certificates/${id}`)
      setStatus(data.status)
      const ev = await api.get(`/certificates/${id}/events`)
      setEvents(ev.data)
    })()
    socket.emit('joinCertRoom', String(id))
    const onUpdate = (payload) => {
      if (payload.id === Number(id)) {
        setStatus(payload.status)
        setEvents(prev => ([...prev, { status: payload.status, note: 'Actualizado', created_at: new Date().toISOString() }]))
      }
    }
    socket.on('statusUpdated', onUpdate)
    return () => socket.off('statusUpdated', onUpdate)
  }, [id])

  return (
    <div>
      <h2>Seguimiento del Certificado #{id}</h2>
      <div>Estado actual: <strong>{status}</strong></div>
      <h3>Historial</h3>
      <ul>
        {events.map((e, i) => (
          <li key={i}>{new Date(e.created_at).toLocaleString()} - {e.status} {e.note ? `(${e.note})` : ''}</li>
        ))}
      </ul>
    </div>
  )
}
