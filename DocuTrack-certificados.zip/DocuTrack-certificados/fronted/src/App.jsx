import { Routes, Route, Link, Navigate } from 'react-router-dom'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Dashboard from './pages/Dashboard.jsx'
import RequestCertificate from './pages/RequestCertificate.jsx'
import Track from './pages/Track.jsx'
import AdminPanel from './pages/AdminPanel.jsx'
import { useAuth } from './state/AuthContext.jsx'
import './app.css'

function Nav() {
  const { user, logout } = useAuth()
  return (
    <nav className="navbar">
      <Link to="/" className="nav-logo">Certificados</Link>
      <div className="nav-links">
        {user && <Link to="/dashboard">Mis certificados</Link>}
        {user && user.role === 'admin' && <Link to="/admin">Admin</Link>}
        {!user ? (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Registro</Link>
          </>
        ) : (
          <button onClick={logout} className="logout-btn">Salir</button>
        )}
      </div>
    </nav>
  )
}

function PrivateRoute({ children, role }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (role && user.role !== role) return <Navigate to="/" replace />
  return children
}

export default function App() {
  return (
    <div className="app-container">
      <Nav/>
      <div className="content-wrapper">
        <Routes>
          <Route path="/" element={<div className="welcome">Bienvenido al sistema de certificados</div>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/register" element={<Register/>} />
          <Route path="/dashboard" element={<PrivateRoute><Dashboard/></PrivateRoute>} />
          <Route path="/request" element={<PrivateRoute><RequestCertificate/></PrivateRoute>} />
          <Route path="/track/:id" element={<PrivateRoute><Track/></PrivateRoute>} />
          <Route path="/admin" element={<PrivateRoute role="admin"><AdminPanel/></PrivateRoute>} />
        </Routes>
      </div>
    </div>
  )
}
